require("dotenv").config({ path: __dirname + "/.env" });
const axios = require ("axios");

exports.getSearch = (req,res,next)=>{
   axios.get("http://localhost:3000/products/category/"+req.query.search).then(response =>{
        if(response.data != "")
        {
            res.status(200).json(response.data);
        }
        else
        {
            res.status(501).json({message:"No such category exist"})
        }
  
    }).catch(err =>{
        if(err)
        {
            
            throw err;
        }
    })
};
