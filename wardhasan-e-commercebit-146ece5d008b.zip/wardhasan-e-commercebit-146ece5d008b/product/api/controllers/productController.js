const productSchema = require("../models/productsSchema");


require("dotenv").config({ path: __dirname + "/.env" });



exports.addProduct = (req,res,next)=>{
    console.log(req.body.name);
    console.log(req.file.path)
    const newProduct = new productSchema({
        productName: req.body.name,
        productPrice: req.body.price,
        productCategory: req.body.category,
        productIsFeatured:req.body.isfeatured,
        productImage:req.file.path
      });
      newProduct.save().then(()=>{
        res.json({message : "product created"})
      }).catch((err)=>{
          if(err)
          {
              throw err;
          }
      });
    
};

exports.getIsFeaturedProducts = (req,res,next)=>{
    const isfeatured_1 = 1;
    productSchema.find({productIsFeatured:isfeatured_1}).select("productName productCategory productPrice productComments productRattingAvg productImage").then((doc)=>{
        if (doc) {
            res.status(200).json(
                doc
            );
        } else {
            res.status(404).json({
                message: "there are no featured products"
            });
        }
    }).catch(err =>{
        if(err){
            throw err;
        }
    })
};
exports.getProductByCategory = (req,res,next)=>{
productSchema.find({productCategory:req.params.categoryname}).then((doc)=>{
    
    if (doc) {
        res.status(200).json(
            doc
        );
    } else {
        res.status(404).json({
            message: "there are no such category"
        });
    }
}).catch(err=>{
    if(err){
        throw err;
    }
})
};

exports.getProductById = (req,res,next)=>{
    console.log(req.params)
    productSchema.findOne({_id:req.params.productId}).select("productName productCategory productPrice productComments productRattingAvg productImage").then((doc)=>{
        if (doc) {
            res.status(200).json(
                doc
            );
        } else {
            res.status(404).json({
                message: "there are no featured products"
            });
        }
    }).catch(err =>{
        if(err){
            throw err;
        }
    })
}

