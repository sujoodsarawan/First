const express = require("express");
const app = express();
const morgan = require("morgan");
const bodyParser = require("body-parser");
const path = require("path");
const productsRoute = require("./api/routes/productRoute");

require('dotenv').config();
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);

app.use(morgan("dev"));
app.use(bodyParser.json());
console.log(__dirname);
app.use(express.static('uploads'));
app.use(express.static('./public/assets'));
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  //which kind of headers we want to accept
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With Content-Type, Accept, Authrization"
  );
  if (req.method === "OPTIONS") {
    //browsers will send an aptions request by default
    res.header("Access-Control-Allow-Methods", "PUT, POST, PATCH, DELETE, GET");
    return res.status(HttpStatus.OK).json({});
  }
  next();
  //so that the other routes can take over
});

app.use("/products", productsRoute);

app.use((req, res, next) => {
  const error = new Error("Not Found");
  error.status = 404;
  next(error);
});

app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message
    }
  });
});

module.exports = app;
