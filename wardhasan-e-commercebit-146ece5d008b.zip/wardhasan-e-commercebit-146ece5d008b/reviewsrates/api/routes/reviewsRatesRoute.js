const express = require('express');
const router = express.Router();
const reviewsRatesController = require('../controllers/reviewsRatesController');

router.post('/addReviewsRates',reviewsRatesController.addReviewsRates);
module.exports = router;