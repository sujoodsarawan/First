require("dotenv").config({ path: __dirname + "/.env" });
const productSchema = require("../models/productSchema");
const math = require("mathjs");
exports.addReviewsRates = (req, res, next) => {
  const updateOps = {};
  for (const ops of req.body) {
    updateOps[ops.propName] = ops.value;
  }
  productSchema
    .findOne({
      _id:updateOps["productId"],
    })
    .select("productComments productRattingAvg")
    .then(doc => {
      const rattings = [];

      doc.productComments.forEach(element => {
        rattings.push(element.userRating);
      });
      //this push was made to add the current ratting to the AVG ratting.
     
      rattings.push(updateOps["productComments"][2]["value"]);
      console.log(rattings);
      var rate = math.mean(rattings);

      if (rate > 4) rate = 4;
      

      if (rate > 0 && rate < 1) rate = 1;
      productSchema
        .updateOne(
          {
            _id:updateOps["productId"],
            productCategory: updateOps["productCategory"],
            productName: updateOps["productName"]
          },
          {
            $push: {
              productComments: {
                userName: updateOps["productComments"][0]["value"],
                comment: updateOps["productComments"][1]["value"],
                userRating: updateOps["productComments"][2]["value"]
              }
            },
            $set: {
              productRattingAvg: parseInt(rate)
            }
          }
        )
        .then(doc => {
          if (doc) {
            res.status(200).json({
              message: doc
            });
          } else {
            res.status(404).json({
              message: "product doesn't exist"
            });
          }
        })
        .catch(err => {
          if (err) {
            throw err;
          }
        });
     
    })
    .catch(err => {
      if (err) {
        throw err;
      }
    });

};
