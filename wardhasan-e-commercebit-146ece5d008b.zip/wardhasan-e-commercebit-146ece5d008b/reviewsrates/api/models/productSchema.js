const database = require('../config/database');
const productSchema = database.Schema({
    productPrice:{ type: Number, required:true} ,
    productName: { type: String, required: true },
    productCategory: { type: String , required:true},
    productIsFeatured : {type:Boolean,required:true},
    productComments :[{
        userName : String,
        comment : String,
        userRating:Number
         }],
    productRattingAvg: {type : Number, default:0},
    productImage:{type : String,required:true}
});
const x = database
//console.log(x)
//console.log(productSchema)

module.exports = database.model('productSchema', productSchema);