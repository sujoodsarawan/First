const mongoose = require("mongoose");

require('dotenv').config({path: __dirname + '/.env'})

const dbpath = process.env.dp_path;
    
mongoose.connect(dbpath, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;

//console.log(db)
db.on("error", () => {
    console.log("> error occurred from the database");
    
});
db.once("open", () => {
    console.log("> successfully opened the database");
   // console.log(db)
   
});

module.exports = mongoose;
